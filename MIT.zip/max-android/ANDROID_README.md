# Max AI Assistant — Android (Samsung Galaxy M14 / F14 5G)

The original repo is an **iOS** app (Swift/SwiftUI). This `android/` folder is a native **Android port**
(Kotlin + Jetpack Compose) that runs on the Samsung Galaxy M14 5G / F14 5G (Android 13+, minSdk 26).

## Easiest way to get the APK (no PC / no Android Studio)

1. Copy the `android/` folder and the `.github/` folder into the **root of your GitHub repo** and commit.
2. On GitHub open the **Actions** tab -> **Build Android APK** -> **Run workflow**.
3. When it finishes (about 5 min), open the run and download the artifact **max-ai-debug-apk**.
4. Unzip it, copy `app-debug.apk` to the phone and tap it.
   (Allow "Install unknown apps" for your file manager / browser when asked.)

## Or build with Android Studio

Open the `android/` folder, wait for Gradle sync, plug the phone in (USB debugging on) and press Run.
Command line: `cd android && gradle assembleDebug` -> `app/build/outputs/apk/debug/app-debug.apk`

## First launch

Tap the gear icon and paste your **OpenAI API key** (required). The **Serper key** is optional (web/news search).
Choose the voice language (English or Bangla) and Save.

## What works

| Feature | Android implementation |
|---|---|
| Chat with persona, JSON replies, follow-up chips | OpenAI `gpt-4o-mini` |
| Voice input | Push-to-talk (🎤) with Android SpeechRecognizer; Bangla / English / Hindi |
| "Hey Max" hands-free | Works **while the app is open on screen** |
| Spoken replies | Android TextToSpeech |
| Vision | 📷 takes a photo with the phone camera and sends it with your question |
| Web / news search | Serper (optional) |
| 3-tier memory (facts / episodes / summaries) | JSON files in app storage; keyword-based relevance |
| API keys | Stored encrypted (EncryptedSharedPreferences) |

## Not ported (iOS / Meta-glasses specific)

- Ray-Ban Meta glasses streaming (Meta iOS SDK, `MWDAT*`) — the phone camera replaces it.
- Visual-memory gallery ("Remember This", object index, location tags).
- Apple on-device embeddings (replaced by keyword matching).
- Always-on background wake word — Android blocks background microphone use without a foreground service.

## Notes

- Bangla speech recognition and voice need the Google app / Google Speech Services; on Samsung, make sure
  Bangla is installed under Settings -> General management -> Language -> Text-to-speech.
- Hands-free mode uses the system recognizer, so Samsung may play a small listening sound repeatedly.
- This is a debug-signed APK for personal use. For Play Store you need a release keystore.
- The code was written without a build environment available, so if Gradle reports a compile error,
  send me the message and I'll fix it.
