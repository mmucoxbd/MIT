package com.maxai.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Speech-to-text using Android's built-in SpeechRecognizer (Google speech service on Samsung).
 *  - push-to-talk: one utterance, then stops
 *  - wake mode ("Hey Max"): keeps listening while the app is on screen
 * Must be created and used on the main thread.
 */
class VoiceInput(
    private val ctx: Context,
    private val onFinalText: (String) -> Unit,
    private val onListening: (Boolean) -> Unit,
    private val onFailure: (String) -> Unit
) {
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var locale = "en-US"
    private var wake = false
    private var active = false
    private var paused = false
    private var awaitingCommand = false

    private val wakeRegex = Regex(
        "(hey|hi|hay|ok|okay|হেই|হ্যালো|হে)\\s*,?\\s*(max|mac|macs|maks|ম্যাক্স|ম্যাক্সি|ম্যাক|ম্যাকস)",
        RegexOption.IGNORE_CASE
    )

    fun start(localeTag: String, wakeMode: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFailure("Speech recognition is not available on this phone. Install/enable the Google app.")
            return
        }
        locale = localeTag
        wake = wakeMode
        active = true
        paused = false
        awaitingCommand = false
        listen()
    }

    fun stop() {
        active = false
        paused = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        onListening(false)
    }

    /** Resume wake-mode listening after the assistant finished thinking/speaking. */
    fun resume() {
        if (active && paused) {
            paused = false
            listen()
        }
    }

    private fun listen() {
        if (!active || paused) return
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onListening(true) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                handle(text)
            }

            override fun onError(error: Int) {
                val benign = error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                if (wake && active && (benign || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY)) {
                    handler.postDelayed({ listen() }, 500)
                } else {
                    active = false
                    onListening(false)
                    if (!benign) onFailure(describe(error))
                }
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
        onListening(true)
    }

    private fun handle(text: String) {
        if (!wake) {
            active = false
            onListening(false)
            if (text.isNotBlank()) onFinalText(text)
            return
        }
        // wake mode
        val m = wakeRegex.find(text)
        when {
            m != null -> {
                val rest = text.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
                if (rest.isNotBlank()) deliver(rest)
                else { awaitingCommand = true; listen() }
            }
            awaitingCommand && text.isNotBlank() -> { awaitingCommand = false; deliver(text) }
            else -> listen()
        }
    }

    private fun deliver(text: String) {
        paused = true
        onListening(false)
        onFinalText(text)
    }

    private fun describe(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network problem during speech recognition."
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
        else -> "Speech recognition error ($code)."
    }
}
