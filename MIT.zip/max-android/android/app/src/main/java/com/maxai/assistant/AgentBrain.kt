package com.maxai.assistant

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Orchestrates one AI turn: intent -> (web search) -> memory -> OpenAI -> store memories. */
class AgentBrain(ctx: Context) {
    val memory = MemoryStore(ctx.applicationContext)
    private val recent = ArrayDeque<Turn>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    data class Reply(val answer: String, val followUps: List<String>)

    suspend fun respond(query: String, image: Bitmap?): Reply {
        // 1. Optional web search (only when a Serper key exists and there is no photo)
        var searchBlock = ""
        if (image == null && Prefs.serperKey.isNotBlank()) {
            val (intent, sq) = classify(query)
            if (intent == "search" || intent == "news") {
                try {
                    val res = SerperClient.search(sq.ifBlank { query }, intent == "news")
                    if (res.isNotBlank()) searchBlock = res
                } catch (_: Exception) { }
            }
        }

        // 2. Build prompt with memory
        val system = Soul.buildSystemPrompt(memory.context(query))
        val turns = mutableListOf(Turn("system", system))
        turns.addAll(recent)

        var userContent = query
        if (image != null) {
            userContent += "\n\n(The user attached a photo taken with the phone camera. Answer based on it.)"
        }
        if (searchBlock.isNotEmpty()) {
            userContent += "\n\nWEB SEARCH RESULTS (use them to answer; never read URLs aloud):\n$searchBlock"
        }
        turns.add(Turn("user", userContent))

        // 3. Ask the model
        val raw = OpenAiClient.chat(
            turns,
            imageB64 = image?.let { ImageUtil.toBase64Jpeg(it) },
            json = true,
            maxTokens = 400
        )
        val reply = parseReply(raw)

        // 4. Short-term + long-term memory
        recent.addLast(Turn("user", query))
        recent.addLast(Turn("assistant", reply.answer))
        while (recent.size > 8) recent.removeFirst()
        remember(query, reply.answer)
        return reply
    }

    fun clearSession() = recent.clear()

    // ── helpers ────────────────────────────────────────────────────────────

    private suspend fun classify(query: String): Pair<String, String> {
        return try {
            val raw = OpenAiClient.chat(
                listOf(
                    Turn(
                        "system",
                        "Classify the message for a voice assistant. Return JSON only: " +
                            "{\"intent\":\"chat|search|news\",\"query\":\"short web search query or empty\"}. " +
                            "search = needs current real-world info from the web (weather, prices, scores, places, " +
                            "things that change). news = asks for latest news or headlines. " +
                            "chat = everything else (personal, conversation, general knowledge, opinions)."
                    ),
                    Turn("user", query)
                ),
                json = true, maxTokens = 60, temperature = 0.0
            )
            val o = JSONObject(stripFences(raw))
            o.optString("intent", "chat") to o.optString("query", "")
        } catch (e: Exception) {
            "chat" to ""
        }
    }

    private fun remember(query: String, answer: String) {
        scope.launch {
            try {
                memory.addEpisode("User: $query | Max: $answer")
                extractFacts(query, answer).forEach { memory.addFact(it) }
                memory.oldestForSummary()?.let { old ->
                    val text = OpenAiClient.chat(
                        listOf(
                            Turn(
                                "system",
                                "Summarize these conversation snippets into one compact paragraph (under 150 words). " +
                                    "Keep names, preferences, plans and important details."
                            ),
                            Turn("user", old.joinToString("\n") { it.text })
                        ),
                        maxTokens = 300, temperature = 0.3
                    )
                    if (text.isNotBlank()) memory.commitSummary(text.trim(), old)
                }
            } catch (_: Exception) { }
        }
    }

    private suspend fun extractFacts(query: String, answer: String): List<String> {
        if (query.length < 4) return emptyList()
        return try {
            val raw = OpenAiClient.chat(
                listOf(
                    Turn(
                        "system",
                        "Extract durable personal facts the USER stated about themselves or their life " +
                            "(names, relationships, location, job, preferences, routines). " +
                            "Ignore questions and small talk. Write each fact in third person, e.g. " +
                            "\"The user's wife is named Sara\". " +
                            "Return JSON only: {\"facts\":[\"...\"]}. Use an empty list if there are none."
                    ),
                    Turn("user", "User said: $query\nAssistant replied: $answer")
                ),
                json = true, maxTokens = 200, temperature = 0.0
            )
            val arr = JSONObject(stripFences(raw)).optJSONArray("facts") ?: return emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val s = arr.optString(i).trim()
                    if (s.isNotEmpty()) add(s)
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseReply(raw: String): Reply {
        return try {
            val o = JSONObject(stripFences(raw))
            val ans = o.optString("answer", "").trim()
            val fu = o.optJSONArray("followUps")
            val chips = buildList {
                if (fu != null) for (i in 0 until fu.length()) {
                    val s = fu.optString(i).trim()
                    if (s.isNotEmpty()) add(s)
                }
            }.take(3)
            Reply(ans.ifEmpty { raw.trim() }, chips)
        } catch (e: Exception) {
            Reply(raw.trim(), emptyList())
        }
    }

    private fun stripFences(s: String): String =
        s.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
}
