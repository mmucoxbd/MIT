package com.maxai.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Memory(val id: String, val text: String, val ts: Long)
data class MemoryContext(val facts: List<Memory>, val episodes: List<Memory>, val summaries: List<Memory>)

/**
 * Three-tier memory (same idea as the iOS app): facts, conversation episodes, summaries.
 * Stored as JSON files in the app's private storage. Relevance uses keyword overlap
 * (the iOS version used Apple's on-device NLEmbedding, which Android doesn't have).
 */
class MemoryStore(ctx: Context) {
    private val dir: File = ctx.filesDir
    private var facts: MutableList<Memory> = load("max_facts.json")
    private var episodes: MutableList<Memory> = load("max_episodes.json")
    private var summaries: MutableList<Memory> = load("max_summaries.json")

    private val stop = setOf(
        "the", "and", "for", "are", "was", "with", "that", "this", "have", "has", "from",
        "what", "who", "how", "you", "your", "his", "her", "its", "about", "user", "max", "can"
    )

    private fun keywords(text: String): Set<String> =
        text.lowercase().split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length > 2 && it !in stop }.toSet()

    @Synchronized
    fun addFact(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val kw = keywords(t)
        val idx = facts.indexOfFirst { old ->
            val ok = keywords(old.text)
            val shared = ok.intersect(kw).size
            val denom = minOf(ok.size, kw.size)
            shared >= 3 || (denom > 0 && shared.toDouble() / denom >= 0.7)
        }
        val m = Memory(UUID.randomUUID().toString(), t, System.currentTimeMillis())
        if (idx >= 0) facts[idx] = m else facts.add(m)
        if (facts.size > 80) facts = facts.takeLast(80).toMutableList()
        save("max_facts.json", facts)
    }

    @Synchronized
    fun addEpisode(text: String) {
        episodes.add(Memory(UUID.randomUUID().toString(), text.take(600), System.currentTimeMillis()))
        save("max_episodes.json", episodes)
    }

    @Synchronized
    fun context(query: String): MemoryContext {
        val qk = keywords(query)
        val relevant = episodes
            .map { it to keywords(it.text).intersect(qk).size }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(4).map { it.first }
        val picked = (relevant + episodes.takeLast(2)).distinctBy { it.id }.sortedBy { it.ts }
        return MemoryContext(facts.takeLast(25), picked, summaries.takeLast(3))
    }

    /** Oldest 40 episodes once more than 60 exist, so they can be compressed into a summary. */
    @Synchronized
    fun oldestForSummary(): List<Memory>? =
        if (episodes.size > 60) episodes.take(40).toList() else null

    @Synchronized
    fun commitSummary(text: String, replaced: List<Memory>) {
        val ids = replaced.map { it.id }.toSet()
        episodes = episodes.filter { it.id !in ids }.toMutableList()
        summaries.add(Memory(UUID.randomUUID().toString(), text, System.currentTimeMillis()))
        save("max_episodes.json", episodes)
        save("max_summaries.json", summaries)
    }

    @Synchronized
    fun clear() {
        facts.clear(); episodes.clear(); summaries.clear()
        save("max_facts.json", facts); save("max_episodes.json", episodes); save("max_summaries.json", summaries)
    }

    private fun load(name: String): MutableList<Memory> {
        val f = File(dir, name)
        if (!f.exists()) return mutableListOf()
        return try {
            val arr = JSONArray(f.readText())
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Memory(o.getString("id"), o.getString("text"), o.getLong("ts"))
            }
        } catch (e: Exception) { mutableListOf() }
    }

    private fun save(name: String, list: List<Memory>) {
        try {
            val arr = JSONArray()
            list.forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("ts", it.ts)) }
            val tmp = File(dir, "$name.tmp")
            tmp.writeText(arr.toString())
            tmp.renameTo(File(dir, name))
        } catch (_: Exception) { }
    }
}
