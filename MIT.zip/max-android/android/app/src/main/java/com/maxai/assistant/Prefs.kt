package com.maxai.assistant

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API keys and settings. Keys are stored encrypted on-device when possible. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = try {
            val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                ctx, "max_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            ctx.getSharedPreferences("max_prefs", Context.MODE_PRIVATE)
        }
    }

    var openAiKey: String
        get() = sp.getString("openai_key", "") ?: ""
        set(v) { sp.edit().putString("openai_key", v.trim()).apply() }

    var serperKey: String
        get() = sp.getString("serper_key", "") ?: ""
        set(v) { sp.edit().putString("serper_key", v.trim()).apply() }

    var model: String
        get() = (sp.getString("model", "") ?: "").ifBlank { "gpt-4o-mini" }
        set(v) { sp.edit().putString("model", v.trim()).apply() }

    var speechLocale: String
        get() = sp.getString("speech_locale", "en-US") ?: "en-US"
        set(v) { sp.edit().putString("speech_locale", v).apply() }

    var speak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) { sp.edit().putBoolean("speak", v).apply() }
}
