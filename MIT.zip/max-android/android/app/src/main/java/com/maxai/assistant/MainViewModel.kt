package com.maxai.assistant

import android.app.Application
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean, val image: Bitmap? = null)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val messages = mutableStateListOf<ChatMessage>()
    var thinking by mutableStateOf(false); private set
    var listening by mutableStateOf(false); private set
    var handsFree by mutableStateOf(false); private set
    var followUps by mutableStateOf<List<String>>(emptyList()); private set
    var pendingImage by mutableStateOf<Bitmap?>(null)
    var errorMsg by mutableStateOf<String?>(null)
    var speakReplies by mutableStateOf(Prefs.speak)

    private val brain = AgentBrain(app)

    private val voice = VoiceInput(
        app,
        onFinalText = { send(it) },
        onListening = { listening = it },
        onFailure = { errorMsg = it; handsFree = false }
    )

    private val speaker = Speaker(app) { if (handsFree) voice.resume() }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || thinking) return
        val img = pendingImage
        pendingImage = null
        messages.add(ChatMessage(text, true, img))
        followUps = emptyList()
        errorMsg = null
        thinking = true

        viewModelScope.launch {
            try {
                val reply = brain.respond(text, img)
                messages.add(ChatMessage(reply.answer, false))
                followUps = reply.followUps
                if (speakReplies) speaker.speak(reply.answer, Prefs.speechLocale)
                else if (handsFree) voice.resume()
            } catch (e: ApiException) {
                errorMsg = e.message
                if (handsFree) voice.resume()
            } catch (e: Exception) {
                errorMsg = "Something went wrong: ${e.message}"
                if (handsFree) voice.resume()
            } finally {
                thinking = false
            }
        }
    }

    /** Push-to-talk button. */
    fun micTap() {
        if (handsFree) return
        if (listening) { voice.stop(); return }
        speaker.stop()
        voice.start(Prefs.speechLocale, wakeMode = false)
    }

    fun setHandsFree(on: Boolean) {
        handsFree = on
        if (on) { speaker.stop(); voice.start(Prefs.speechLocale, wakeMode = true) }
        else voice.stop()
    }

    /** Called when the app leaves the screen: Android won't let us listen in the background. */
    fun stopListening() {
        speaker.stop()
        if (handsFree) handsFree = false
        voice.stop()
    }

    fun clearChat() {
        messages.clear()
        followUps = emptyList()
        brain.clearSession()
    }

    fun forgetEverything() {
        clearChat()
        brain.memory.clear()
    }

    override fun onCleared() {
        voice.stop()
        speaker.shutdown()
        super.onCleared()
    }
}
