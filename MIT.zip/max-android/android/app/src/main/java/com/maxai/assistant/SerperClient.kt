package com.maxai.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Web / news search through serper.dev (optional). */
object SerperClient {
    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String, news: Boolean): String = withContext(Dispatchers.IO) {
        val key = Prefs.serperKey
        if (key.isBlank()) return@withContext ""
        val country = Locale.getDefault().country.lowercase().ifBlank { "us" }
        val endpoint = if (news) "https://google.serper.dev/news" else "https://google.serper.dev/search"
        val body = JSONObject().put("q", query).put("gl", country).put("num", 5)

        val req = Request.Builder()
            .url(endpoint)
            .header("X-API-KEY", key)
            .post(body.toString().toRequestBody(JSON_TYPE))
            .build()

        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return@withContext ""
            val root = JSONObject(resp.body?.string().orEmpty())
            val sb = StringBuilder()

            root.optJSONObject("answerBox")?.let { ab ->
                val a = ab.optString("answer").ifBlank { ab.optString("snippet") }
                if (a.isNotBlank()) sb.append("Direct answer: ").append(a).append('\n')
            }
            val arr = root.optJSONArray(if (news) "news" else "organic")
            if (arr != null) {
                for (i in 0 until minOf(arr.length(), 5)) {
                    val o = arr.getJSONObject(i)
                    sb.append("- ").append(o.optString("title"))
                    val snip = o.optString("snippet")
                    if (snip.isNotBlank()) sb.append(": ").append(snip)
                    val date = o.optString("date")
                    if (date.isNotBlank()) sb.append(" (").append(date).append(')')
                    sb.append('\n')
                }
            }
            sb.toString().trim()
        }
    }
}
