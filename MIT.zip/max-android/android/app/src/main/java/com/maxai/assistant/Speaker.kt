package com.maxai.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Text-to-speech wrapper. Calls [onFinished] on the main thread when speech ends. */
class Speaker(ctx: Context, private val onFinished: () -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { main.post { onFinished() } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { main.post { onFinished() } }
            })
        }
    }

    fun speak(text: String, localeTag: String) {
        val engine = tts
        if (!ready || engine == null) { onFinished(); return }
        engine.setLanguage(Locale.forLanguageTag(localeTag))
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "max_utt")
    }

    fun stop() { tts?.stop() }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
