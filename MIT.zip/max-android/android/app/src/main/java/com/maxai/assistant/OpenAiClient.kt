package com.maxai.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(message: String) : Exception(message)

data class Turn(val role: String, val content: String)

/** Minimal OpenAI Chat Completions client (text + vision, optional JSON mode). */
object OpenAiClient {
    private const val URL = "https://api.openai.com/v1/chat/completions"
    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun chat(
        turns: List<Turn>,
        imageB64: String? = null,
        json: Boolean = false,
        maxTokens: Int = 400,
        temperature: Double = 0.7
    ): String = withContext(Dispatchers.IO) {
        val key = Prefs.openAiKey
        if (key.isBlank()) throw ApiException("OpenAI API key missing. Open Settings (⚙️) and add it.")

        val msgs = JSONArray()
        val lastUser = turns.indexOfLast { it.role == "user" }
        turns.forEachIndexed { i, t ->
            val m = JSONObject().put("role", t.role)
            if (imageB64 != null && i == lastUser) {
                val parts = JSONArray()
                parts.put(JSONObject().put("type", "text").put("text", t.content))
                parts.put(
                    JSONObject().put("type", "image_url").put(
                        "image_url",
                        JSONObject().put("url", "data:image/jpeg;base64,$imageB64").put("detail", "auto")
                    )
                )
                m.put("content", parts)
            } else {
                m.put("content", t.content)
            }
            msgs.put(m)
        }

        val body = JSONObject()
            .put("model", Prefs.model)
            .put("messages", msgs)
            .put("temperature", temperature)
            .put("max_tokens", maxTokens)
        if (json) body.put("response_format", JSONObject().put("type", "json_object"))

        val req = Request.Builder()
            .url(URL)
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody(JSON_TYPE))
            .build()

        try {
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw ApiException(errorMessage(resp.code, text))
                JSONObject(text).getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").optString("content", "")
            }
        } catch (e: IOException) {
            throw ApiException("No internet connection or the server could not be reached.")
        }
    }

    private fun errorMessage(code: Int, body: String): String {
        val detail = try {
            JSONObject(body).getJSONObject("error").optString("message", "")
        } catch (e: Exception) { "" }
        return when (code) {
            401 -> "OpenAI API key is invalid. Check it in Settings."
            429 -> "OpenAI rate limit or quota reached. Check your billing/credits."
            else -> "OpenAI error $code. $detail".trim()
        }
    }
}
