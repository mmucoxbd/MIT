package com.maxai.assistant

import android.app.Application

class MaxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
