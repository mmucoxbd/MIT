package com.maxai.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MaxScreen(vm)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        vm.stopListening()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaxScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // ── microphone permission ───────────────────────────────────────────
    var pendingMicAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingMicAction?.invoke()
        else vm.errorMsg = "Microphone permission is needed for voice. You can still type."
        pendingMicAction = null
    }
    fun withMic(action: () -> Unit) {
        val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (has) action() else { pendingMicAction = action; micPermission.launch(Manifest.permission.RECORD_AUDIO) }
    }

    // ── camera (full-resolution photo via the Samsung camera app) ───────
    val photoFile = remember { File(File(ctx.cacheDir, "camera").apply { mkdirs() }, "photo.jpg") }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) vm.pendingImage = ImageUtil.decode(photoFile.absolutePath)
    }
    fun takePhoto() {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", photoFile)
        cameraLauncher.launch(uri)
    }

    val itemCount = vm.messages.size + if (vm.thinking) 1 else 0
    LaunchedEffect(itemCount) {
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Max") },
                actions = {
                    Text("Hey Max", fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                    Switch(
                        checked = vm.handsFree,
                        onCheckedChange = { on -> if (on) withMic { vm.setHandsFree(true) } else vm.setHandsFree(false) }
                    )
                    IconButton(onClick = { vm.clearChat() }) { Text("🗑️") }
                    IconButton(onClick = { showSettings = true }) { Text("⚙️") }
                }
            )
        }
    ) { inner ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .consumeWindowInsets(inner)
                .imePadding()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (vm.messages.isEmpty() && !vm.thinking) {
                    item {
                        Text(
                            "Type, tap 🎤 to talk, or 📷 to ask about a photo.\nTurn on \"Hey Max\" for hands-free while the app is open.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 24.dp)
                        )
                    }
                }
                items(vm.messages) { m -> Bubble(m) }
                if (vm.thinking) item { Text("Max is thinking…", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }

            if (vm.followUps.isNotEmpty()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(vm.followUps) { chip ->
                        AssistChip(onClick = { vm.send(chip) }, label = { Text(chip) })
                    }
                }
            }

            vm.errorMsg?.let {
                Text(
                    it, color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), fontSize = 13.sp
                )
            }

            vm.pendingImage?.let { bmp ->
                Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        bmp.asImageBitmap(), contentDescription = "Attached photo",
                        modifier = Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Photo attached", Modifier.weight(1f))
                    TextButton(onClick = { vm.pendingImage = null }) { Text("Remove") }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { takePhoto() }) { Text("📷", fontSize = 22.sp) }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask Max…") },
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" })
                )
                Spacer(Modifier.width(4.dp))
                if (input.isBlank()) {
                    IconButton(onClick = { withMic { vm.micTap() } }, enabled = !vm.handsFree) {
                        Text(if (vm.listening) "⏹️" else "🎤", fontSize = 24.sp)
                    }
                } else {
                    Button(onClick = { vm.send(input); input = "" }, enabled = !vm.thinking) { Text("Send") }
                }
            }
        }
    }

    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

@Composable
fun Bubble(m: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.isUser) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (m.isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                m.image?.let {
                    Image(
                        it.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.height(6.dp))
                }
                Text(m.text)
            }
        }
    }
}

@Composable
fun SettingsDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var openai by remember { mutableStateOf(Prefs.openAiKey) }
    var serper by remember { mutableStateOf(Prefs.serperKey) }
    var model by remember { mutableStateOf(Prefs.model) }
    var locale by remember { mutableStateOf(Prefs.speechLocale) }
    var speak by remember { mutableStateOf(vm.speakReplies) }
    val languages = listOf(
        "en-US" to "English (US)",
        "bn-BD" to "বাংলা (বাংলাদেশ)",
        "bn-IN" to "বাংলা (ভারত)",
        "hi-IN" to "हिन्दी"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    openai, { openai = it }, label = { Text("OpenAI API key") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    serper, { serper = it }, label = { Text("Serper API key (optional, web search)") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(model, { model = it }, label = { Text("Model") }, singleLine = true)

                Text("Voice language", fontSize = 13.sp)
                languages.forEach { (tag, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = locale == tag, onClick = { locale = tag })
                        Text(label)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = speak, onCheckedChange = { speak = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Speak replies aloud")
                }
                TextButton(onClick = { vm.forgetEverything() }) {
                    Text("Forget everything Max remembers", color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Prefs.openAiKey = openai
                Prefs.serperKey = serper
                Prefs.model = model
                Prefs.speechLocale = locale
                Prefs.speak = speak
                vm.speakReplies = speak
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
